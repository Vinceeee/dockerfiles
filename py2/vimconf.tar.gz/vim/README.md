## 本人自用VIM配置

- 使用pathogen进行vim包管理 -- [pathogen](https://github.com/tpope/vim-pathogen)
- 配置了如下三个python包
  1. jedi-vim , 一个python代码 auto-complete 的vim包
  2. syntatic ， 语法错误检测 
  3. vim-snippets , 代码块自动填充，可以高度个性化定制
- 对.vimrc的配置
  
