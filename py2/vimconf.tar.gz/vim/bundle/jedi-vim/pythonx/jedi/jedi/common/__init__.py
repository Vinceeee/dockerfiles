from jedi.common.context import BaseContextSet, BaseContext
